<?php
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $oldal=$_GET["oldal"];
    $ellenorzes="SELECT * FROM megtekintések WHERE oldal='$oldal'";
    $id_l="SELECT id FROM megtekintések";
    $id=$kapcsolat->query($id_l)->num_rows+1;
    $van_e=$kapcsolat->query($ellenorzes)->num_rows;
    if($van_e>0)
    {
        $frissites="UPDATE megtekintések SET mennyiség=mennyiség+1 WHERE oldal='$oldal'";
        $kapcsolat->query($frissites);
    }
    else{
        $kuldes="INSERT INTO megtekintések(id,oldal,mennyiség) VALUES('$id','$oldal',1)";
        $kapcsolat->query($kuldes);
    }
?>