<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons-1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/gombok formása.css">
    <link rel="stylesheet" href="css/formázások.css">
    <link rel="icon" type="image/x-icon" href="Képek/Logo.png">
    <script src='bootstrap/js/bootstrap.bundle.min.js'></script>
    <script src="js/funkciók.js"></script>
    <title id="oldal">Fiók szerkesztése</title>
</head>
<?php
$email_v="";
$felhasznalonev_v="";
$jelszo_v="";
$jelszo_i_v="";
$email_f="is-valid";
$felhasznalonev_f="is-valid";
$jelszo_f="is-valid";
$jelszo_i_f="is-valid";
if($_SERVER["REQUEST_METHOD"]=="POST")
{
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    if(isset($_POST["mentés"]))
    {
        session_start();
        $felhasznalonev=$_SESSION["felhasználónév"];
        $jelszo=$_SESSION["jelszó"];
        $email=$_POST["email"];
        $uj_felhasznalonev=$_POST["felhasználónév"];
        $uj_jelszo=$_POST["jelszó"];
        $jelszo_i=$_POST["jelszó_i"];
        $ellenorzes="SELECT * FROM fiókok WHERE felhasználónevek='$felhasznalonev' and jelszavak='$jelszo'";
        $eredmeny=$kapcsolat->query($ellenorzes);
        $sor=$eredmeny->fetch_assoc();
        $id=$sor["id"];
        if(empty($email))
        {
            $email_v="Minden mezőt ki kell tölteni";
            $email_f="is-invalid";
        }
        else
        {
            if(!filter_var($email,FILTER_VALIDATE_EMAIL))
            {
                $email_v="Ez az email cím nem valódi!";
                $email_f="is-invalid";    
            }
            else
            {
                $email_v="";
                $email_f="is-valid";
            }
        }

        if(empty($uj_felhasznalonev))
        {
            $felhasznalonev_v="Minden mezőt ki kell tölteni!";
            $felhasznalonev_f="is-invalid";
        }
        else
        {
            if(!preg_match("/[a-zA-Z-0-9]/",$uj_felhasznalonev))
            {
                $felhasznalonev_v="A felhasználónév nem valódi!";
                $felhasznalonev_f="is-invalid";
            }
            else
            {
                if($uj_felhasznalonev!=$felhasznalonev)
                {
                    $ellenorzes="SELECT * FROM fiókok WHERE felhasználónevek='$uj_felhasznalonev'";
                    $eredmeny=$kapcsolat->query($ellenorzes);
                    $van_e=$eredmeny->num_rows;
                    if($van_e>0)
                    {
                        $felhasznalonev_f="is-invalid";
                        $felhasznalonev_v="Ez a felhasználónév már foglalt!";
                        $felhasznalonev=$uj_felhasznalonev;
                    }
                    else
                    {
                        $felhasznalonev_f="is-valid";
                        $felhasznalonev_v="";
                    }
                }
                else
                {
                    $felhasznalonev_f="is-valid";
                    $felhasznalonev_v="";
                }
            }
        }

        if(empty($uj_jelszo))
        {
            $jelszo_v="Minden mezőt ki kell tölteni!";
            $jelszo_f="is-invalid";
        }
        else
        {
            if(strlen($uj_jelszo)<8)
            {
                $jelszo_v="A jelszónak 8 vagy több karakter hosszúnak kell lennie!";
                $jelszo_f="is-invalid";
            }
            else
            {
                if(!preg_match("#[A-Z]+#",$uj_jelszo))
                {
                    $jelszo_v="A jelszónak tartalmaznia kell nagy betűt!";
                    $jelszo_f="is-invalid";
                }
                else
                {
                    if(!preg_match("#[a-z]+#",$uj_jelszo))
                    {
                        $jelszo_v="A jelszónak tartalmaznia kell kis betűt!";
                        $jelszo_f="is-invalid";
                    }
                    else
                    {
                        if(!preg_match("#[0-9]+#",$uj_jelszo))
                        {
                            $jelszo_v="A jelszónak tartalmaznia kell számot!";
                            $jelszo_f="is-invalid";
                        }
                        else
                        {
                            $jelszo_v="";
                            $jelszo_f="is-valid";
                        }
                    }
                }
            }
        }

        if(empty($jelszo_i))
        {
            $jelszo_i_v="Minden mezőt ki kell tölteni!";
            $jelszo_i_f="is-invalid";
        }
        else
        {
            if($uj_jelszo!=$jelszo_i)
            {
                $jelszo_i_v="A jelszavak nem egyeznek!";
                $jelszo_i_f="is-invalid";
            }
            else
            {
                $jelszo_i_v="";
                $jelszo_i_f="is-valid";
            }
        }

        if($email_v=="" && $felhasznalonev_v=="" && $jelszo_v=="" && $jelszo_i_v=="")
        {
            if(mail($email,"Regisztrálás","Kedves ".$uj_felhasznalonev."\nKöszönjük hogy regisztrált!"))
            {
                sleep(2);
                $imap=imap_open("{imap.gmail.com:993/imap/ssl/novalidate-cert}INBOX","kpatyi0202@gmail.com","ivfy vbbg fwzd mzsb") or die("Can't connect: " . imap_last_error());
                $van_e=imap_search($imap, 'SUBJECT "Delivery Status Notification (Failure)"');
                if($van_e)
                {   
                    foreach($van_e as $i)
                    {
                        imap_delete($imap, $i);
                        imap_expunge($imap);
                    }
                    $email_v="Ez az email cím nem létezik!";
                    $email_f="is-invalid";
                }
                else
                {
                    $email_v="";
                    $email_f="is-valid";
                    $frissites="UPDATE fiókok SET felhasználónevek='$uj_felhasznalonev',jelszavak='$uj_jelszo',email='$email' WHERE felhasználónevek='$felhasznalonev'";
                    if($kapcsolat->query($frissites))
                    {
                        $_SESSION["felhasználónév"]=$uj_felhasznalonev;
                        $_SESSION["jelszó"]=$uj_jelszo;
                        header("Location: Főoldal.php");
                    }
                }
            }
            imap_close($imap);
        }
    }
}
else
{
    session_start();
    $felhasznalonev=$_SESSION["felhasználónév"];
    $jelszo=$_SESSION["jelszó"];
    if($felhasznalonev==null)
    {
        header("Location:Bejelentkezés.php");
    }
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $ellenorzes="SELECT * FROM fiókok WHERE felhasználónevek='$felhasznalonev' and jelszavak='$jelszo'";
    $eredmeny=$kapcsolat->query($ellenorzes);
    $sor=$eredmeny->fetch_assoc();
    $id=$sor["id"];
    $email=$sor["email"];
    $jelszo_i=$sor["jelszavak"];
}
echo
"
<body onload='szamolas()'> 
    <div class='d-flex vh-100'>
    <form novalidate action='".htmlspecialchars($_SERVER["PHP_SELF"])."' class='m-auto needs-validation' method='post'>
        <h1 id='r_b' class='mb-5 text-center'>Fiók szerkesztés</h1>
        <div class='input-group mb-3'>
            <i class='bi bi-at input-group-text'></i>
            <div class='form-floating'>
                <input autocomplete='off' id='email' type='email' class='form-control $email_f' name='email' value='$email'>
                <label for='email'>Email cím</label>
                <div class='invalid-tooltip'>
                    $email_v
                </div>
            </div>
        </div>
        <div class='input-group mb-3'>
            <i class='bi bi-person-fill input-group-text'></i>
            <div class='form-floating'>
                <input autocomplete='off' id='felhasznalonev' type='text' class='form-control $felhasznalonev_f' value='$felhasznalonev' name='felhasználónév'>
                <label for='felhasznalonev'>Felhasználónév</label>
                <div class='invalid-tooltip'>
                    $felhasznalonev_v
                </div>
            </div>
        </div>
        <div class='input-group mb-3'>
            <i class='bi bi-lock-fill input-group-text'></i>
            <div class='form-floating'>
                <input type='password' id='jelszo' class='form-control $jelszo_f' value='$jelszo' name='jelszó'>
                <label for='jelszo'>Jelszó</label>
                <div class='invalid-tooltip'>
                    $jelszo_v
                </div>
            </div>
            <i class='bi bi-eye-fill input-group-text' onclick='mutasd_j()' id='mutasd_j'></i>
        </div>
        <div class='input-group mb-3'>
            <i class='bi bi-lock-fill input-group-text'></i>
            <div class='form-floating'>
                <input type='password' class='form-control $jelszo_i_f' id='jelszo_i' value='$jelszo_i' name='jelszó_i'>
                <label for='jelszo_i'>Jelszó megerősítése</label>
                <div class='invalid-tooltip'>
                    $jelszo_i_v
                </div>
            </div>
            <i onclick='mutasd_j_i()' class='bi bi-eye-fill input-group-text' id='mutasd_j_i'></i>
        </div>
        <div class='input-group mb-3'>";
    $tortenetek_l="SELECT cím FROM történetek WHERE f_id='$id'";
    $tortenetek=$kapcsolat->query($tortenetek_l);
    $darab=$tortenetek->num_rows;
    if($darab>0)
    {
        echo
        "
        <div class='dropdown form-floating'>
                <input autocomplete='off' class='form-select dropdown-toggle' id='t_cim' name='cim' onkeyup='kereses_to()' type='text' data-bs-toggle='dropdown'>
                <ul class='dropdown-menu cimek w-100' aria-labelledby='cim' id='lehetosegek'>";
        while($sor=$tortenetek->fetch_assoc())
        {
            $cim=$sor["cím"];
            echo
            "
                    <li  onclick='"."valasztot_to(".'"'."$cim".'"'.")'"."class='dropdown-item'>$cim</li>";
        }
        echo
        "
                </ul>
                <label for='tortenet' class='form-label'>Válasz egy történetet:</label>
                <div class='invalid-tooltip'>
                    Válasz történetet
                </div>
            </div>
            <button onclick='van_cim()' type='button' class='btn btn-primary'>Szerkesztés</button>
        </div>
        ";
    }
    else
    {
        echo
        "
        <div class='dropdown form-floating'>
                <input autocomplete='off' class='form-select dropdown-toggle' id='t_cim' name='cim' value='Még nincs történeted' disabled type='text' data-bs-toggle='dropdown'>
                <ul class='dropdown-menu megyek w-100' aria-labelledby='cim' id='lehetosegek'>
                </ul>
                <label for='t_cim' class='form-label'>Válasz egy címet:</label>
                <div class='invalid-tooltip'>
                    Válasz címet
                </div>
            </div>
            <button onclick='van_cim()' type='button' class='btn btn-primary'>Szerkesztés</button>
        </div>
        ";

    }
    echo
        "
        <div class='container mt-5'>
            <div class='row'>
                <div class='col-4 text-start'>
                    <a href='Főoldal.php' class='btn btn-primary'>Vissza</a>
                </div>
                <div class='col-4 text-center'>
                    <a href='Törlés.php' class='btn btn-danger'>Törlés</a>
                </div>
                <div class='col-4 text-end'>
                    <button type='submit' name='mentés' class='btn btn-success'>Mentés</button>
                </div>
            </div>
        </div>
    </form>
</body>    
    ";
?>