<?php
$email_v="";
$felhasznalonev_v="";
$jelszo_v="";
$jelszo_i_v="";
$email_f="";
$felhasznalonev_f="";
$jelszo_f="";
$jelszo_i_f="";
$email="";
$felhasznalonev="";
$jelszo="";
$jelszo_i="";

if($_SERVER["REQUEST_METHOD"]=="POST")
{
  $adatbazis="adatok";
  $hostname="localhost";
  $adatbazis_felhasznalonev="root";
  $adatbazis_jelszo="";
  $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
  if(!$kapcsolat)
  {
      die("Sikertelen kapcsolódás: ".mysqli_connect_error());
  }
  $email=$_POST["email"];
  $felhasznalonev=$_POST["felhasználónév"];
  $jelszo=$_POST["jelszó"];
  $jelszo_i=$_POST["jelszó_i"];
  if(empty($email))
  {
    $email_v="Minden mezőt ki kell tölteni";
    $email_f="is-invalid";
  }
  else
  {
      if(!filter_var($email,FILTER_VALIDATE_EMAIL))
      {
        $email_v="Ez az email cím nem valódi!";
        $email_f="is-invalid";    
      }
      else
      {
        $email_v="";
        $email_f="is-valid";
      }
  }
  if(empty($felhasznalonev))
  {
    $felhasznalonev_v="Minden mezőt ki kell tölteni!";
    $felhasznalonev_f="is-invalid";
  }
  else
  {
      if(!preg_match("/[a-zA-Z-0-9]/",$felhasznalonev))
      {
        $felhasznalonev_v="A felhasználónév nem valódi!";
        $felhasznalonev_f="is-invalid";
      }
      else
      {
          $ellenorzes="SELECT * FROM fiókok WHERE felhasználónevek='$felhasznalonev'";
          $eredmeny=$kapcsolat->query($ellenorzes);
          $van_e=$eredmeny->num_rows;
          if($van_e>0)
          {
            $felhasznalonev_v="Ez a felhasználónév már foglalt!";
            $felhasznalonev_f="is-invalid";
          }
          else
          {
            $felhasznalonev_v="";
            $felhasznalonev_f="is-valid";
          }
      }
  }
  if(empty($jelszo))
  {
    $jelszo_v="Minden mezőt ki kell tölteni!";
    $jelszo_f="is-invalid";
  }
  else
  {
      if(strlen($jelszo)<8)
      {
        $jelszo_v="A jelszónak 8 vagy több karakter hosszúnak kell lennie!";
        $jelszo_f="is-invalid";
      }
      else
      {
          if(!preg_match("#[A-Z]+#",$jelszo))
          {
            $jelszo_v="A jelszónak tartalmaznia kell nagy betűt!";
            $jelszo_f="is-invalid";
          }
          else
          {
              if(!preg_match("#[a-z]+#",$jelszo))
              {
                $jelszo_v="A jelszónak tartalmaznia kell kis betűt!";
                $jelszo_f="is-invalid";
              }
              else
              {
                  if(!preg_match("#[0-9]+#",$jelszo))
                  {
                    $jelszo_v="A jelszónak tartalmaznia kell számot!";
                    $jelszo_f="is-invalid";
                  }
                  else
                  {
                    $jelszo_v="";
                    $jelszo_f="is-valid";
                  }
              }
          }
      }
  }
  if(empty($jelszo_i))
  {
    $jelszo_i_v="Minden mezőt ki kell tölteni!";
    $jelszo_i_f="is-invalid";
  }
  else
  {
      if($jelszo!=$jelszo_i)
      {
        $jelszo_i_v="A jelszavak nem egyeznek!";
        $jelszo_i_f="is-invalid";
      }
      else
      {
        $jelszo_i_v="";
        $jelszo_i_f="is-valid";
      }
  }
  if($email_v=="" && $felhasznalonev_v=="" && $jelszo_v=="" && $jelszo_i_v=="")
  {
      if(mail($email,"Regisztrálás","Kedves ".$felhasznalonev."\nKöszönjük hogy regisztrált!"))
      {
          sleep(2);
          $imap=imap_open("{imap.gmail.com:993/imap/ssl/novalidate-cert}INBOX","kpatyi0202@gmail.com","ivfy vbbg fwzd mzsb") or die("Can't connect: " . imap_last_error());
          $van_e=imap_search($imap, 'SUBJECT "Delivery Status Notification (Failure)"');
          if($van_e)
          {   
            foreach($van_e as $i)
            {
              imap_delete($imap, $i);
              imap_expunge($imap);
            }
            $email_v="Ez az email cím nem létezik!";
            $email_f="is-invalid";
          }
          else
          {
            $email_v="";
            $email_f="is-valid";
            $idik_l="SELECT id FROM fiókok ORDER BY id";
            $idik=$kapcsolat->query($idik_l);
            $id=1;
            while($sor=$idik->fetch_assoc())
            {
                if($sor["id"]==$id)
                {
                    $id++;
                }
                else
                {
                    break;
                }
            }
            $bekuldes="INSERT INTO fiókok(id,felhasználónevek,jelszavak,email) VALUES($id,'$felhasznalonev','$jelszo','$email')";
            $kapcsolat->query($bekuldes);
            session_start();
            $_SESSION["felhasználónév"]=$felhasznalonev;
            $_SESSION["jelszó"]=$jelszo;
            header("Location: Főoldal.php");
          }
      }
      imap_close($imap);
  }
}
?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons-1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/gombok formása.css">
    <link rel="stylesheet" href="css/formázások.css">
    <link rel="icon" type="image/x-icon" href="Képek/Logo.png">
    <script src="js/funkciók.js"></script>
    <title id="oldal">Regisztráció</title>
</head>
<body onload="szamolas()">
  <div class="d-flex vh-100">
    <form novalidate action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="m-auto needs-validation" method="post">
      <h1 id="r_b" class="mb-5 text-center">Regisztráció</h1>
      <div class="input-group mb-3">
        <i class="bi bi-at input-group-text"></i>
        <div class="form-floating">
          <input autocomplete="off" id="email" type="email" class="form-control <?php echo"$email_f"?>" name="email" value="<?php echo "$email";?>">
          <label for="email">Email cím</label>
          <div class="invalid-tooltip">
            <?php echo"$email_v";?>
          </div>
        </div>
      </div>
      <div class="input-group mb-3">
        <i class="bi bi-person-fill input-group-text"></i>
        <div class="form-floating">
          <input autocomplete="off" id="felhasznalonev" type="text" class="form-control <?php echo"$felhasznalonev_f";?>" value="<?php echo "$felhasznalonev";?>" name="felhasználónév">
          <label for="felhasznalonev">Felhasználónév</label>
          <div class="invalid-tooltip">
            <?php echo"$felhasznalonev_v";?>
          </div>
        </div>
      </div>
      <div class="input-group mb-3">
        <i class="bi bi-lock-fill input-group-text"></i>
        <div class="form-floating">
          <input type="password" id="jelszo" class="form-control <?php echo"$jelszo_f;"?>" value="<?php echo "$jelszo";?>" name="jelszó">
          <label for="jelszo">Jelszó</label>
          <div class="invalid-tooltip">
            <?php echo"$jelszo_v";?>
          </div>
        </div>
        <i class="bi bi-eye-fill input-group-text" onclick="mutasd_j()" id="mutasd_j"></i>
      </div>
      <div class="input-group mb-3">
        <i class="bi bi-lock-fill input-group-text"></i>
        <div class="form-floating">
          <input type="password" id="jelszo_i" class="form-control <?php echo"$jelszo_i_f";?>" value="<?php echo "$jelszo_i";?>" name="jelszó_i">
          <label for="jelszo_i">Jelszó megerősítése</label>
          <div class="invalid-tooltip">
            <?php echo"$jelszo_i_v";?>
          </div>
        </div>
        <i onclick="mutasd_j_i()" class="bi bi-eye-fill input-group-text" id="mutasd_j_i"></i>
      </div>
      <div class="d-flex justify-content-end mt-4">
        <a href="Bejelentkezés.php">Van fiókod? Jelentkezz be</a>
      </div>
      <div class="container mt-4 ms-3"> 
        <div class="row">
          <div class="col-6">
            <a class="btn btn-primary me-5" href="Főoldal.html">
              Vissza
            </a>
          </div>
          <div class="col-6">
            <button class="btn btn-primary" type="submit" name="beküldés">Regisztrálás</button>
          </div>
        </div>
      </div>
    </form>
  </div>
</body>
</html>