<?php
$felhasznalonev_v="";
$jelszo_v="";
$felhasznalonev_f="";
$jelszo_f="";
$felhasznalonev="";
$jelszo="";

if($_SERVER["REQUEST_METHOD"]=="POST")
{
  $adatbazis="adatok";
  $hostname="localhost";
  $adatbazis_felhasznalonev="root";
  $adatbazis_jelszo="";
  $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
  if(!$kapcsolat)
  {
      die("Sikertelen kapcsolódás: ".mysqli_connect_error());
  }
  $felhasznalonev=$_POST["felhasználónév"];
  $jelszo=$_POST["jelszó"];
  if(empty($felhasznalonev))
  {
    $felhasznalonev_v="Minden mezőt ki kell tölteni!";
    $felhasznalonev_f="is-invalid";
  }
  else
  {
      if(!preg_match("/[a-zA-Z-0-9]/",$felhasznalonev))
      {
        $felhasznalonev_v="A felhasználónév nem valódi!";
        $felhasznalonev_f="is-invalid";
      }
      else
      {
          $ellenorzes="SELECT * FROM fiókok WHERE felhasználónevek='$felhasznalonev'";
          $eredmeny=$kapcsolat->query($ellenorzes);
          $van_e=$eredmeny->num_rows;
          if($van_e>0)
          {
            $felhasznalonev_v="";
            $felhasznalonev_f="is-valid";
          }
          else
          {
            $felhasznalonev_v="Ez a felhasználónév már foglalt vagy még nem regisztrált!";
            $felhasznalonev_f="is-invalid";
          }
      }
  }
  if(empty($jelszo))
  {
    $jelszo_v="Minden mezőt ki kell tölteni!";
    $jelszo_f="is-invalid";
  }
  else
  {
      if(strlen($jelszo)<8)
      {
        $jelszo_v="A jelszónak 8 vagy több karakter hosszúnak kell lennie!";
        $jelszo_f="is-invalid";
      }
      else
      {
          if(!preg_match("#[A-Z]+#",$jelszo))
          {
            $jelszo_v="A jelszónak tartalmaznia kell nagy betűt!";
            $jelszo_f="is-invalid";
          }
          else
          {
              if(!preg_match("#[a-z]+#",$jelszo))
              {
                $jelszo_v="A jelszónak tartalmaznia kell kis betűt!";
                $jelszo_f="is-invalid";
              }
              else
              {
                  if(!preg_match("#[0-9]+#",$jelszo))
                  {
                    $jelszo_v="A jelszónak tartalmaznia kell számot!";
                    $jelszo_f="is-invalid";
                  }
                  else
                  {
                    $ellenorzes="SELECT * FROM fiókok WHERE felhasználónevek='$felhasznalonev' AND jelszavak='$jelszo'";
                    $eredmeny=$kapcsolat->query($ellenorzes);
                    $van_e=$eredmeny->num_rows;
                    if($van_e==0)
                    {
                        $jelszo_v="Hibás felhasználónév vagy jelszó!";
                        $jelszo_f="is-invalid";
                        $felhasznalonev_f="is-invalid";
                    }
                    else
                    {
                        $jelszo_v="";
                        $jelszo_f="is-valid";
                        session_start();
                        $_SESSION["felhasználónév"]=$_POST["felhasználónév"];
                        $_SESSION["jelszó"]=$_POST["jelszó"];
                        header("Location: Főoldal.php");
                    }
                  }
              }
          }
      }
  }
}
?>
<!DOCTYPE html>
<html lang="hu">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons-1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/gombok formása.css">
    <link rel="stylesheet" href="css/formázások.css">
    <link rel="icon" type="image/x-icon" href="Képek/Logo.png">
    <script src="js/funkciók.js"></script>
    <title id="oldal">Bejelentkezés</title>
  </head>
  <body onload="szamolas()">
    <div class="d-flex vh-100">
      <form novalidate action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" class="m-auto needs-validation" method="post">
        <h1 id="r_b" class="mb-5 text-center">Bejelentkezés</h1>
        <div class="input-group mb-3">
          <i class="bi bi-person-fill input-group-text"></i>
          <div class="form-floating">
            <input autocomplete="off" type="text" id="felhasznalonev" class="form-control <?php echo"$felhasznalonev_f";?>" value="<?php echo "$felhasznalonev";?>" name="felhasználónév">
            <label for="felhasznalonev">Felhasználónév</label>
            <div class="invalid-tooltip">
                <?php echo"$felhasznalonev_v"?>
            </div>
          </div>
        </div>
        <div class="input-group mb-3">
          <i class="bi bi-lock-fill input-group-text"></i>
          <div class="form-floating">
            <input type="password" class="form-control <?php echo"$jelszo_f"?>" value="<?php echo "$jelszo";?>" id="jelszo" name="jelszó">
            <label for="jelszo">Jelszó</label>
            <div class="invalid-tooltip">
                <?php echo"$jelszo_v";?>
            </div>
          </div>
          <i class="bi bi-eye-fill input-group-text" onclick="mutasd_j()" id="mutasd_j"></i>
        </div>
        <div id="b_r" class="d-flex justify-content-end mt-4">
          <a href="Regisztráció.php">Még nincs fiókod? Regisztrálj</a>
        </div>
        <div class="container mt-4 ms-3"> 
          <div class="row">
            <div class="col-6">
              <a class="btn btn-primary me-5" href="Főoldal.html">
                Vissza
              </a>
            </div>
            <div class="col-6">
              <button class="btn btn-primary" type="submit" name="beküldés">Bejelentkezés</button>
            </div>
          </div>
        </div>
      </form>
    </div>
  </body>
</html>