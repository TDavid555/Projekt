<?php
    session_start();
    $felhasznalonev=$_SESSION["felhasználónév"];
    $jelszo=$_SESSION["jelszó"];
    $cim=$_SESSION["cím"];
    $adatbazis="adatok";
    $hostname="localhost";
    $adatbazis_felhasznalonev="root";
    $adatbazis_jelszo="";
    $kapcsolat= mysqli_connect($hostname,$adatbazis_felhasznalonev,$adatbazis_jelszo,$adatbazis);
    if(!$kapcsolat)
    {
        die("Sikertelen kapcsolódás: ".mysqli_connect_error());
    }
    $fajlok="SELECT történet_hely FROM történetek,fiókok WHERE felhasználónevek='$felhasznalonev' AND történetek.f_id=fiókok.id AND cím='$cim'";
    $eredmeny=$kapcsolat->query($fajlok)->fetch_assoc();
    unlink("történetek/".$eredmeny["történet_hely"]);
    $torles="DELETE FROM történetek WHERE f_id IN(SELECT id FROM fiókok WHERE felhasználónevek='$felhasznalonev') AND cím='$cim'";
    $kapcsolat->query($torles);
?>